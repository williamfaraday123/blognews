import styles from "./categoryList.module.css";

const CategoryList = () => {
    return (
        <div className={styles.container}>
            CategoryList
        </div>
    );
};

export default CategoryList;