import { ThemeContext } from "@/context/ThemeContext";
import { useContext } from "react";
import styles from "./themeToggle.module.css";

const ThemeToggle = () => {

    const { theme, toggle } = useContext(ThemeContext);
    return (
        <div className={styles.container} onClick={toggle}>
            {theme === "light" ? "dark mode" : "light mode"}
        </div>
    );
};

export default ThemeToggle;