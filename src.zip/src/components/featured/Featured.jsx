import styles from "./featured.module.css";

const Featured = () => {
    return (
        <div className={styles.container}>
            Featured
        </div>
    );
};

export default Featured;