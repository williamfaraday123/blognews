import styles from "./footer.module.css";

const Footer = () => {
    return (
        <div className={styles.container}>
            Footer
        </div>
    );
};

export default Footer;