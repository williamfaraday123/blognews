import styles from "./menu.module.css";

const Menu = () => {
    return (
        <div className={styles.container}>
            Menu
        </div>
    );
};

export default Menu;